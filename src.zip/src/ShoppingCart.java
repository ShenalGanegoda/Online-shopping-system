import java.util.ArrayList;

public class ShoppingCart {
    public ArrayList<Product> cartProductsList = new ArrayList<>(); // List contains the users chosen products

    public void addToCart(){} // Method to add products to cart
    public void removeFromCart(){} // Method to remoce products from cart
    public void CalculateTotalCost(){} // Method to calculate total cost
}
