public interface ShoppingManager {
    public void addNewProduct();
    public void deleteProduct();
    public void printListOfProducts();
    public void saveInFile();

}
